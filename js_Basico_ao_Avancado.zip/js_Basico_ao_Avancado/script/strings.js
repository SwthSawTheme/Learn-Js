// Variaveis do tipo String
console.log("Jogos mortais III")
console.log("Cemitério Maldito")
console.log("Esc\"ape")


var string = "texto"
console.log(string.length)

// Percorrendo uma string
for (i=0; i < string.length; i++){
    console.log(string[i])
}