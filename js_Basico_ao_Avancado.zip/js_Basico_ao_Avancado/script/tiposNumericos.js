// Trabalhando com Tipos numéricos
console.log(1.1)
console.log(1.2)
console.log(0.12)
console.log(1,2)
// Numero de pi usando lib Math
console.log(Math.PI)
// Raiz quadrada usando Math
console.log(Math.sqrt(16))
// Numero de Euler
console.log(Math.E)