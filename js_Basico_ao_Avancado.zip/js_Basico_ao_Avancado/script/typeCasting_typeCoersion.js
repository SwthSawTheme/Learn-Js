
// casting é quando você converte um dado

console.log(Number("2") + 4)

// coersion é quando a VM do Js trata esse dado