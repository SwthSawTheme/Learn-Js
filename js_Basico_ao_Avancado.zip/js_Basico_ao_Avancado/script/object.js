// Objetos

console.log({ propriedade: "valor"})

console.log({
    nome: "Saw",
    idade: 25,
    altura: 1.89,
    teste: {
        nome: "Magic",
        power: "Fire",
        damage: 678.5
    }
})