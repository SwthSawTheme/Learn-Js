// Falsy and Truthly

console.log( 0 ? "Verdadeiro" : "False")
console.log(-0 ? "Verdadeiro" : "Falso")
console.log(0n ? "Verdadeiro" : "Falso")
console.log(null ? "Verdadeiro" : "Falso")
console.log(undefined ? "Verdadeiro" : "Falso")
console.log(NaN ? "Verdadeiro" : "Falso")
