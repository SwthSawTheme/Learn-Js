// Not a Number
console.log(NaN)

var divisao = "a" / 2 * ("a" * "b")
console.log(divisao)