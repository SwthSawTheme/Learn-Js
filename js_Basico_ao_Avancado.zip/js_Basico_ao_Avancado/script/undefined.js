// Diferença entre null e undefined

console.log(null)
console.log(undefined)
console.log(typeof undefined)

console.log(null == undefined)
console.log(null === undefined)