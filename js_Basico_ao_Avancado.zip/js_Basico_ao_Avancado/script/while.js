
// Enquanto a condição for verdadeiro, execute

var contador = 0

while (contador < 10) {
    console.log(`Executando... ${contador + 1}`)
    contador ++
}

console.log("Fim da execução!")