console.log(Date())

console.log(new Date())