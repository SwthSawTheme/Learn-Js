
const valor = 11

if ( 1 >= valor && valor <= 5) {
    console.log("Está dentro do range")
} else if ( valor >= 6 && valor <= 10) {
    console.log("Ainda está dentro do range")
} else {
    console.log("Está fora do range")
}