if ( true ){
    console.log("verdadeiro")
} else {
    console.log("Falso")
}

if ( 1 === 3 ) {
    console.log("Verdadeiro")
} else {
    console.log("Falso")
}