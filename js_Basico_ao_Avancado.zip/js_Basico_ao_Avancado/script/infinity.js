console.log(Infinity)
console.log(1/0)
console.log(typeof Infinity)