
// Variavel iniciada "undefined"
let test

// Variavel iniciada "undefined"
var number

// Constante é obrigatório a atribuição de valor
const userful = 1.0

// Variavel declarada "Assignment"
var name = "Saw"