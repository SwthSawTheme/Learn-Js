var peso = 83
var altura = 1.89

var resultado = peso / altura

console.log(resultado)