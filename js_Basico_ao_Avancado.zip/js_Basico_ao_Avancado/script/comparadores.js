
// Comparadores em Js

var numero = 1 > 2 // 1 maior que 2
var numero1 = 1 < 2 // 1 menor que 2
var numero2 = 1 == 1 // 1 igual a 1
var numero3 = 3 != 2 // 3 diferente de 2

console.log(numero,numero1,numero2,numero3)