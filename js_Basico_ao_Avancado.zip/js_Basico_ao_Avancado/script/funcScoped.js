const numero = function(obj) {
    obj *= obj
    return obj
}

console.log(numero(3))