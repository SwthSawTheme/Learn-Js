
// comparação normal em Js

var teste = "1" == 1
var teste1 = null == undefined

console.log(teste)
console.log(teste1)

// comparação estrita ou "identica"
var teste2 = "1" === 1
var teste3 = null === undefined
var teste4 = null !== undefined

console.log(teste2)
console.log(teste3)
console.log(teste4)