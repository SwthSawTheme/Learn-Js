
// Os operadores obedecem as ordens de precedência aritmética
// () -> (* e /) -> (+ e -) 

let n1, n2, n3, n4

n1 = 5.0
n2 = 4.0
n3 = 10
n4 = 2.2

var media = (n1 + n2 + n3 + n4) / 4

console.log(`A média aritmética é de ${media}`)