
const numero = (obj) => (obj *= obj)

console.log(numero(20))