
// Declaração por agrupamento
var test, sum, min

test = "teste"
sum = 3 + 3
min = 0.5

console.log(test,sum,min)