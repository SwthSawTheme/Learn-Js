
var lista = ["Uno","Duno","caind","Suin","duli","Min"]

//for (var i=0; i < 100; i++) {
//    console.log(`Então é ${lista[i]}`)
//}

for (const nome of lista) {
    console.log(nome)
}