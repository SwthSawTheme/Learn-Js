console.log(true)   // Verdadeiro
console.log(false)  // Falso

console.log(0 == false)
// exemplo

var cliente = false

if (cliente == true){
    console.log("Acesso autorizado!")
} else {
    console.log("Acesso negado!")
}