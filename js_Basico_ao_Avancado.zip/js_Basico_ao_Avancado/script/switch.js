
const valor = 8

switch (valor) {
    case 1:
        console.log("Condição 1")
        break
    case 2:
        console.log("Condição 2")
        break
    case 3:
        console.log("Condição 3")
        break
    default:
        console.log("Condição padrão")
        break
}