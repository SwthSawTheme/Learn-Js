
let num = 0
num = num + 1
num++
num++
num--

var num1 = 20
num1 -= 10
num1 *= 2

console.log(num, num1)