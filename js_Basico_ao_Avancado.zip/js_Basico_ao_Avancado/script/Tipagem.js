var bool = true
var number = 20
var string = "texto"
var float = 1.4
var conta = "2" + 2

console.log(typeof bool)
console.log(typeof number)
console.log(typeof string)
console.log(typeof float)
console.log(typeof conta)